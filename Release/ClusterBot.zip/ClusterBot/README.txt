# ClusterBot
Tato hra byla vytvořena součástí předmětu "Řízení projektů" na škole SPŠT
a její vývoj probíhal ve třech týdenních sprintech.

ClusterBot je arkádová top-down střílečka, kde se snažíte přežít co nejdéle a zabít co nejvíce nepřátel
pro získání nejvyššího skóre.
Po zabití nepřítele po něm zůstane lékárnička, která Vás vyléčí, nebo zásobník, 
který Vám doplní nezbytné náboje.
Když Vaše životy klesnou na nulu, hra skončí a pokud jste dosáhli nejvyššího skóre, uloží ho.


Pokud byste chtěli pozměnit vzhled nebo zvuk hry, stačí vyměnit vaše soubory za ty ve složce "Assets".
Soubory se musí jmenovat *ÚPLNĚ STEJNĚ* jako ty, které se tam již nachází.
Pokud změníte obrázek "mapSkeleton.png", změní se collidery mapy. S tím přichází i rozbité spawn pointy.

##Tým
Lukáš Kurtin - Kapitán, programátor, SFX
Jan Mátl - Programátor
Vojtěch Mastný - Grafický designer

##Kontakt
kurtinl.04@spst.eu